//
//  ViewController.swift
//  Commenter
//
//  Created by Gene Lee on 1/25/17.
//  Copyright © 2017 Gene Lee. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    var comments = [Comment]()

    @IBOutlet weak var CommentTextFieldOutlet: UITextField!
    
    /// When tapped, first checks if the comment text field is empty. 
    /// If not, it creates a Comment instance, adds it to an array of Comments, 
    /// and clears the text field.
    @IBAction func AddTapped(_ sender: Any) {
        if !((CommentTextFieldOutlet.text?.isEmpty)!) {
            if let commentText = CommentTextFieldOutlet.text {
                let comment = Comment(commentText)
                self.comments.append(comment)
                
                CommentTextFieldOutlet.text = ""
            }
        } else {
            // Pop up alert to enter a comment
            let alertController = UIAlertController(title: "Oops", message: "Please enter a comment", preferredStyle: .alert)
            let OkAction = UIAlertAction(title: "OK", style: .default, handler: nil)

            alertController.addAction(OkAction)
            
            present(alertController, animated: true, completion: nil)
        }
    }
    
    /// Prints Comment elements of self.comments array
    @IBAction func PrintAllTapped(_ sender: Any) {
        for comment in self.comments {
            print("\(comment.date) \(comment.comment)")
        }
    }
    
    /// Hides the keyboard
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        CommentTextFieldOutlet.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

