//
//  Comment.swift
//  Commenter
//
//  Created by Gene Lee on 1/25/17.
//  Copyright © 2017 Gene Lee. All rights reserved.
//

import Foundation

class Comment {
    var comment: String
    var date: Date
    
    init (_ newComment: String) {
        self.comment = newComment
        self.date = Date()
    }
}
