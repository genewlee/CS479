//
//  ViewController.swift
//  Joker
//
//  Created by Gene Lee on 1/16/17.
//  Copyright © 2017 Gene Lee. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        Punchline.isHidden = true // initally set to hidden
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func AnswerTapped(_ sender: Any) {
        Punchline.isHidden = !Punchline.isHidden
    }

    @IBOutlet weak var AnswerOutlet: UIButton!
    @IBOutlet weak var Punchline: UILabel!
}

